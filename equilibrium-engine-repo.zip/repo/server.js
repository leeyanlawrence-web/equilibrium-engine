/**
 * EQUILIBRIUM API
 * REST API exposing the attacker/defender game-theory engine.
 *
 * Built with ZERO external dependencies (Node's built-in `http` module only)
 * so it runs anywhere with just `node server.js` — no npm install required.
 *
 * Endpoints:
 *   GET  /health                -> health check
 *   GET  /scenarios              -> list preset scenarios + their default params
 *   POST /simulate                -> run a custom simulation, get equilibrium back
 *   POST /simulate/:scenarioId   -> run a preset scenario with overridden params
 */
const http = require("http");
const { URL } = require("url");
const {
  solveEquilibrium,
  SCENARIOS,
  thresholdPosition,
  simulateRepeatedGame,
  compareBanPolicy,
  RANSOMWARE_DEFAULTS,
} = require("./engine.js");

const PORT = process.env.PORT || 3000;

function sendJSON(res, status, body) {
  const data = JSON.stringify(body, null, 2);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  });
  res.end(data);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let chunks = "";
    req.on("data", (c) => (chunks += c));
    req.on("end", () => {
      if (!chunks) return resolve({});
      try {
        resolve(JSON.parse(chunks));
      } catch (e) {
        reject(e);
      }
    });
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname;

  if (req.method === "OPTIONS") {
    return sendJSON(res, 200, {});
  }

  // GET /health
  if (req.method === "GET" && path === "/health") {
    return sendJSON(res, 200, {
      status: "ok",
      service: "equilibrium-engine",
      time: new Date().toISOString(),
    });
  }

  // GET /scenarios
  if (req.method === "GET" && path === "/scenarios") {
    const list = Object.values(SCENARIOS).map((s) => ({
      id: s.id,
      name: s.name,
      question: s.question,
      defaults: s.defaults,
    }));
    return sendJSON(res, 200, { scenarios: list });
  }

  // POST /simulate
  if (req.method === "POST" && path === "/simulate") {
    let body;
    try {
      body = await readBody(req);
    } catch {
      return sendJSON(res, 400, { error: "Invalid JSON body" });
    }
    const required = ["assetValue", "defenseCost", "attackCost", "breachGain", "residualRisk", "detectionProb"];
    const missing = required.filter((k) => body[k] === undefined);
    if (missing.length) {
      return sendJSON(res, 400, { error: "Missing required fields", missing });
    }
    try {
      const result = solveEquilibrium(body);
      return sendJSON(res, 200, { input: body, result });
    } catch (err) {
      return sendJSON(res, 400, { error: "Invalid parameters", detail: err.message });
    }
  }

  // POST /threshold — compute position relative to the unifying threshold law
  if (req.method === "POST" && path === "/threshold") {
    let body;
    try {
      body = await readBody(req);
    } catch {
      return sendJSON(res, 400, { error: "Invalid JSON body" });
    }
    const required = ["attackCost", "breachGain", "detectionProb"];
    const missing = required.filter((k) => body[k] === undefined);
    if (missing.length) {
      return sendJSON(res, 400, { error: "Missing required fields", missing });
    }
    try {
      const result = thresholdPosition(body);
      return sendJSON(res, 200, { input: body, result });
    } catch (err) {
      return sendJSON(res, 400, { error: "Invalid parameters", detail: err.message });
    }
  }

  // POST /repeated-game — simulate belief drift over multiple rounds
  if (req.method === "POST" && path === "/repeated-game") {
    let body;
    try {
      body = await readBody(req);
    } catch {
      return sendJSON(res, 400, { error: "Invalid JSON body" });
    }
    const required = ["assetValue", "defenseCost", "attackCost", "breachGain", "residualRisk", "detectionProb"];
    const missing = required.filter((k) => body[k] === undefined);
    if (missing.length) {
      return sendJSON(res, 400, { error: "Missing required fields", missing });
    }
    const rounds = body.rounds || 12;
    try {
      const result = simulateRepeatedGame(body, rounds);
      return sendJSON(res, 200, { input: body, rounds, result });
    } catch (err) {
      return sendJSON(res, 400, { error: "Invalid parameters", detail: err.message });
    }
  }

  // POST /ransomware-policy — compare payments-allowed vs payments-banned
  if (req.method === "POST" && path === "/ransomware-policy") {
    let body;
    try {
      body = await readBody(req);
    } catch {
      return sendJSON(res, 400, { error: "Invalid JSON body" });
    }
    const merged = { ...RANSOMWARE_DEFAULTS, ...body };
    const rounds = body.rounds || 20;
    try {
      const result = compareBanPolicy(merged, rounds);
      return sendJSON(res, 200, { input: merged, rounds, result });
    } catch (err) {
      return sendJSON(res, 400, { error: "Invalid parameters", detail: err.message });
    }
  }

  // POST /simulate/:scenarioId
  if (req.method === "POST" && path.startsWith("/simulate/")) {
    const scenarioId = path.split("/")[2];
    const scenario = SCENARIOS[scenarioId];
    if (!scenario) {
      return sendJSON(res, 404, { error: "Unknown scenario", available: Object.keys(SCENARIOS) });
    }
    let overrides;
    try {
      overrides = await readBody(req);
    } catch {
      return sendJSON(res, 400, { error: "Invalid JSON body" });
    }
    const merged = { ...scenario.defaults, ...overrides };
    try {
      const params = scenario.mapParams(merged);
      const result = solveEquilibrium(params);
      return sendJSON(res, 200, {
        scenario: scenario.id,
        inputOverrides: overrides,
        mergedParams: merged,
        result,
      });
    } catch (err) {
      return sendJSON(res, 400, { error: "Invalid parameters", detail: err.message });
    }
  }

  return sendJSON(res, 404, { error: "Not found", path });
});

server.listen(PORT, () => {
  console.log(`Equilibrium API running on http://localhost:${PORT}`);
  console.log(`Try: curl http://localhost:${PORT}/scenarios`);
});

module.exports = server;
